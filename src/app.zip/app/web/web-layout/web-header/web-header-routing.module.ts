import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WebHeaderComponent } from './web-header.component';

const routes: Routes = [{ path: '', component: WebHeaderComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WebHeaderRoutingModule { }
