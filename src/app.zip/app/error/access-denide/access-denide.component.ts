import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-access-denide',
  templateUrl: './access-denide.component.html',
  styleUrls: ['./access-denide.component.scss']
})
export class AccessDenideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
